const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 4000;

app.use(cors());
app.use(express.json());

let todos = [
  { id: 1, task: "Learn Node.js", completed: false },
  { id: 2, task: "Build a ToDo app", completed: true }
];

// Get todos
app.get("/todos", (req, res) => res.json(todos));

// Add todo
app.post("/todos", (req, res) => {
  const newTodo = { id: todos.length + 1, task: req.body.task, completed: false };
  todos.push(newTodo);
  res.json(newTodo);
});

// Toggle status
app.put("/todos/:id", (req, res) => {
  const id = parseInt(req.params.id);
  todos = todos.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t));
  res.json({ success: true });
});

// Delete todo
app.delete("/todos/:id", (req, res) => {
  const id = parseInt(req.params.id);
  todos = todos.filter((t) => t.id !== id);
  res.json({ success: true });
});

app.listen(PORT, () => console.log(`✅ Backend running on http://localhost:${PORT}`));
