# 📝 Mini task _ 12 - Full Stack ToDo App

This is a simple **To-Do application** built with:
- **Backend** → Node.js + Express (API for CRUD tasks)
- **Frontend** → React + Tailwind (UI with fetch + useEffect)

---

## 🚀 How to Run

### 1. Clone Repo
```bash
git clone <your-repo-url>.git
cd Mini-task-12
```

### 2. Start Backend
```bash
cd backend
npm install
npm start
```
Runs on: `http://localhost:4000`

### 3. Start Frontend
```bash
cd ../frontend
npm install
npm start
```
Runs on: `http://localhost:3000`
