# 🔐 Mini Task 15 - Full Stack Authentication App

### Backend
- Node.js + Express + JWT + Bcrypt
- Endpoints: `/register`, `/login`, `/profile`

### Frontend
- React + Fetch API
- Register, Login, and View Profile

### How to Run
1. Start backend:
   ```bash
   cd backend
   npm install
   npm start
   ```

2. Start frontend:
   ```bash
   cd frontend
   npm install
   npm start
   ```

3. Open browser → http://localhost:3000
