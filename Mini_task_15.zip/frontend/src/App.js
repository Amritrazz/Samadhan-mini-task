import React, { useState } from "react";

function App() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [token, setToken] = useState("");
  const [profile, setProfile] = useState("");

  const register = async () => {
    await fetch("http://localhost:5000/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });
    alert("Registered!");
  };

  const login = async () => {
    const res = await fetch("http://localhost:5000/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (data.token) {
      setToken(data.token);
      alert("Login successful");
    } else {
      alert("Login failed");
    }
  };

  const getProfile = async () => {
    const res = await fetch("http://localhost:5000/profile", {
      headers: { Authorization: token }
    });
    const data = await res.json();
    setProfile(data.message || data.error);
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">🔐 Auth App</h1>
      <input className="border p-2 mr-2" placeholder="Username"
        value={username} onChange={(e) => setUsername(e.target.value)} />
      <input className="border p-2 mr-2" placeholder="Password" type="password"
        value={password} onChange={(e) => setPassword(e.target.value)} />
      <button onClick={register} className="bg-green-500 text-white px-3 py-1 rounded mr-2">Register</button>
      <button onClick={login} className="bg-blue-500 text-white px-3 py-1 rounded">Login</button>

      <div className="mt-4">
        <button onClick={getProfile} className="bg-purple-500 text-white px-3 py-1 rounded">Get Profile</button>
        <p className="mt-2">{profile}</p>
      </div>
    </div>
  );
}

export default App;
