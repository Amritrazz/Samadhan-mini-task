const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

let products = [
  { id: 1, name: "Laptop", price: 700, description: "Powerful laptop" },
  { id: 2, name: "Phone", price: 300, description: "Smartphone with features" }
];

app.get("/products", (req, res) => res.json(products));

app.post("/products", (req, res) => {
  const newProduct = { id: products.length + 1, ...req.body };
  products.push(newProduct);
  res.json(newProduct);
});

app.delete("/products/:id", (req, res) => {
  const id = parseInt(req.params.id);
  products = products.filter((p) => p.id !== id);
  res.json({ message: "Deleted successfully" });
});

app.listen(PORT, () => console.log(`✅ Store API running on http://localhost:${PORT}`));
