import React, { useState, useEffect } from "react";
import ProductCard from "./components/ProductCard";

function App() {
  const [products, setProducts] = useState([]);
  const [form, setForm] = useState({ name: "", price: "", description: "" });

  useEffect(() => {
    fetch("http://localhost:5000/products")
      .then((res) => res.json())
      .then(setProducts);
  }, []);

  const addProduct = () => {
    fetch("http://localhost:5000/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    })
      .then((res) => res.json())
      .then((newProduct) => {
        setProducts([...products, newProduct]);
        setForm({ name: "", price: "", description: "" });
      });
  };

  const deleteProduct = (id) => {
    fetch(`http://localhost:5000/products/${id}`, { method: "DELETE" })
      .then(() => setProducts(products.filter((p) => p.id !== id)));
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-3xl font-bold mb-4">🛒 Online Store</h1>

      <div className="bg-white p-4 rounded shadow-md mb-6">
        <input className="border p-2 mr-2" placeholder="Name"
          value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <input className="border p-2 mr-2" placeholder="Price"
          value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
        <input className="border p-2 mr-2" placeholder="Description"
          value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
        <button onClick={addProduct} className="bg-blue-500 text-white px-4 py-2 rounded">
          Add Product
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} onDelete={deleteProduct} />
        ))}
      </div>
    </div>
  );
}

export default App;
