import React from "react";

function ProductCard({ product, onDelete }) {
  return (
    <div className="bg-white p-4 rounded shadow-md">
      <h2 className="text-xl font-bold">{product.name}</h2>
      <p className="text-gray-600">${product.price}</p>
      <p className="text-gray-500">{product.description}</p>
      <button onClick={() => onDelete(product.id)} className="bg-red-500 text-white px-2 py-1 rounded mt-2">
        Delete
      </button>
    </div>
  );
}

export default ProductCard;
