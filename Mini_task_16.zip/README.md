# 🛒 Mini Task 16 - Online Store

### Backend
- Node.js + Express
- In-memory product storage
- Runs on `http://localhost:5000`

### Frontend
- React + Tailwind
- Product listing, add & delete
- Runs on `http://localhost:3000`

### How to Run
1. Start backend:
   ```bash
   cd backend
   npm install
   npm start
   ```

2. Start frontend:
   ```bash
   cd frontend
   npm install
   npm start
   ```

3. Open browser → http://localhost:3000
