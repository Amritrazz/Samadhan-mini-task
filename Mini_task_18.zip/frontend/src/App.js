import React, { useState, useEffect } from "react";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";

const API = "http://localhost:5000";

function App() {
  const [token, setToken] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [boards, setBoards] = useState([]);
  const [newBoard, setNewBoard] = useState("");

  const register = async () => {
    await fetch(API + "/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });
    alert("Registered!");
  };

  const login = async () => {
    const res = await fetch(API + "/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (data.token) {
      setToken(data.token);
      loadBoards(data.token);
    }
  };

  const loadBoards = async (tk = token) => {
    const res = await fetch(API + "/boards", { headers: { Authorization: tk } });
    setBoards(await res.json());
  };

  const createBoard = async () => {
    const res = await fetch(API + "/boards", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: token },
      body: JSON.stringify({ title: newBoard })
    });
    const data = await res.json();
    setBoards([...boards, data]);
    setNewBoard("");
  };

  return (
    <div className="p-6">
      {!token ? (
        <div>
          <h1 className="text-2xl mb-4">🔐 Login/Register</h1>
          <input placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} className="border p-2 mr-2"/>
          <input placeholder="Password" type="password" value={password} onChange={e => setPassword(e.target.value)} className="border p-2 mr-2"/>
          <button onClick={register} className="bg-green-500 text-white px-3 py-1 mr-2">Register</button>
          <button onClick={login} className="bg-blue-500 text-white px-3 py-1">Login</button>
        </div>
      ) : (
        <div>
          <h1 className="text-2xl mb-4">📋 My Boards</h1>
          <input placeholder="New board title" value={newBoard} onChange={e => setNewBoard(e.target.value)} className="border p-2 mr-2"/>
          <button onClick={createBoard} className="bg-purple-500 text-white px-3 py-1">Create</button>
          <div className="mt-4 grid grid-cols-3 gap-4">
            {boards.map(b => (
              <div key={b.id} className="bg-gray-100 p-3 rounded shadow">
                <h2 className="font-bold">{b.title}</h2>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
