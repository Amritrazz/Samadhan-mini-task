# 📋 Mini Task 18 - Trello-like Project Management Tool

### Backend
- Node.js + Express + JWT + Bcrypt
- Endpoints: `/register`, `/login`, `/boards`, `/boards/:id/lists`, `/lists/:id/tasks`, `/tasks/:id`

### Frontend
- React + TailwindCSS + react-beautiful-dnd
- Register/Login
- Create Boards, Lists, and Tasks
- Drag & Drop tasks between lists (Kanban style)

### How to Run
1. Start backend:
   ```bash
   cd backend
   npm install
   npm start
   ```

2. Start frontend:
   ```bash
   cd frontend
   npm install
   npm start
   ```

3. Open browser → http://localhost:3000
