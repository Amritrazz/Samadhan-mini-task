const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
const PORT = 5000;
const SECRET = "supersecretkey";

app.use(cors());
app.use(express.json());

let users = [];
let boards = [];

// Middleware to check token
function auth(req, res, next) {
  const token = req.headers["authorization"];
  if (!token) return res.status(401).json({ error: "No token provided" });
  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) return res.status(403).json({ error: "Invalid token" });
    req.user = decoded.username;
    next();
  });
}

// Register
app.post("/register", async (req, res) => {
  const { username, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  users.push({ username, password: hashedPassword });
  res.json({ message: "User registered successfully" });
});

// Login
app.post("/login", async (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username);
  if (!user) return res.status(400).json({ error: "User not found" });

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) return res.status(400).json({ error: "Invalid credentials" });

  const token = jwt.sign({ username }, SECRET, { expiresIn: "1h" });
  res.json({ token });
});

// Boards APIs
app.get("/boards", auth, (req, res) => {
  res.json(boards.filter(b => b.owner === req.user));
});

app.post("/boards", auth, (req, res) => {
  const board = { id: Date.now(), title: req.body.title, owner: req.user, lists: [] };
  boards.push(board);
  res.json(board);
});

app.post("/boards/:id/lists", auth, (req, res) => {
  const board = boards.find(b => b.id == req.params.id && b.owner === req.user);
  if (!board) return res.status(404).json({ error: "Board not found" });
  const list = { id: Date.now(), title: req.body.title, tasks: [] };
  board.lists.push(list);
  res.json(list);
});

app.post("/lists/:id/tasks", auth, (req, res) => {
  for (let board of boards) {
    const list = board.lists.find(l => l.id == req.params.id);
    if (list) {
      const task = { id: Date.now(), title: req.body.title };
      list.tasks.push(task);
      return res.json(task);
    }
  }
  res.status(404).json({ error: "List not found" });
});

app.put("/tasks/:id", auth, (req, res) => {
  for (let board of boards) {
    for (let list of board.lists) {
      const task = list.tasks.find(t => t.id == req.params.id);
      if (task) {
        task.title = req.body.title || task.title;
        return res.json(task);
      }
    }
  }
  res.status(404).json({ error: "Task not found" });
});

app.delete("/tasks/:id", auth, (req, res) => {
  for (let board of boards) {
    for (let list of board.lists) {
      const idx = list.tasks.findIndex(t => t.id == req.params.id);
      if (idx >= 0) {
        list.tasks.splice(idx, 1);
        return res.json({ message: "Task deleted" });
      }
    }
  }
  res.status(404).json({ error: "Task not found" });
});

app.listen(PORT, () => console.log(`✅ Trello API running on http://localhost:${PORT}`));
